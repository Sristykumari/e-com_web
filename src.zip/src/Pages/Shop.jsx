import React from 'react'
import Main from '../Components/Main/Main'

export const Shop = () => {
  return (
    <div>
      <Main/>
    </div>
  )
}
