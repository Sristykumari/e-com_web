import React from 'react'

export const CartNew = () => {
  return (
    <div>CartNew</div>
  )
}
