
import tshirt from '../Assets/product_1.png'
import btshirt from '../Assets/product_3.png'
import tshirt2 from '../Assets/product_2.png'
import tshirtnew from '../Assets/product_4.png'



let data_product =[
    {
        id:1,
        name:'t-shirt 1',
        old_price: 300,
        new_price:200,
        image:tshirt,
       },
       {
        id:2,
       name:'t-shirt 2',
       old_price: 300,
       new_price:500,
       image:tshirt2,
       },
        {
          id:3,
       name:'t-shirt 3',
       old_price: 300,
       new_price:400,
       image:btshirt,
       },
       {
        id:4,
        name:'t-shirt 1',
        old_price: 300,
        new_price:600,
        image:tshirtnew,
       },
    //    {
    //     id:5,
    //    name:'t-shirt 2',
    //    old_price: 300,
    //    new_price:200,
    //    image:btshirt,
    //    },
    //     {
    //     id:6,
    //    name:'t-shirt 3',
    //    old_price: 300,
    //    new_price:200,
    //    image:tshirt,
    //    },
    //    {
    //     id:7,
    //     name:'t-shirt 1',
    //     old_price: 300,
    //     new_price:200,
    //     image:btshirt,
    //    },
    //    {
    //     id:8,
    //    name:'t-shirt 2',
    //    old_price: 300,
    //    new_price:200,
    //    image:tshirt,
    //    },
    //     {
    //         id:9,
    //    name:'t-shirt 3',
    //    old_price: 300,
    //    new_price:200,
    //    image:btshirt,
    //    },
    //    {
    //     id:10,
    //     name:'t-shirt 4',
    //     old_price: 300,
    //     new_price:200,
    //     image:tshirt,
    //     },
    //     {
    //     id:11,
    //     name:'t-shirt 5',
    //     old_price: 300,
    //     new_price:200,
    //     image:btshirt,
    //     },
]
export default data_product